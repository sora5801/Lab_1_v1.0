from FrontEnd import FrontEnd


def main():
    FE = FrontEnd()


if __name__ == "__main__":
    main()
